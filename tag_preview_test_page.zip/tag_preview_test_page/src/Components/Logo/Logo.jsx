function Logo() {
  return (
    <div>
      <img
        src="https://preview.williamsleatag.com/NY/_preview/img/logo.jpg"
        alt="tag_logo"
      />
    </div>
  );
}

export default Logo;
