import styled from "styled-components";

const StyledDiv = styled.h2`
  font-size: 3rem;
  text-align: center;
`;

function Home() {
  return <StyledDiv>Preview page - Home page</StyledDiv>;
}

export default Home;
