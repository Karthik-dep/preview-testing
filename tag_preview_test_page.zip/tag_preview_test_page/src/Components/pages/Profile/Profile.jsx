import styled from "styled-components";

const StyledDiv = styled.h2`
  font-size: 3rem;
  text-align: center;
`;

function Profile() {
  return <StyledDiv>Preview page - Profile page</StyledDiv>;
}

export default Profile;
