import styled from "styled-components";

const StyledDiv = styled.h2`
  font-size: 3rem;
  text-align: center;
`;

function Settings() {
  return <StyledDiv>Preview page - Settings page</StyledDiv>;
}

export default Settings;
